#include <iostream>
#include <cmath>
#include <vector>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "../common/shader.hpp"

int main()
{
    // Initialise GLFW
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW\n";
        return -1;
    }

    // Request OpenGL 3.3 core profile
    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // for MacOS; harmless elsewhere
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Create a windowed mode window and its OpenGL context
    GLFWwindow *window = glfwCreateWindow(800, 600, "First Triangle", NULL, NULL);
    if (!window)
    {
        std::cerr << "Failed to open GLFW window.\n";
        glfwTerminate();
        return -1;
    }

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    glewExperimental = true; // needed in core profile
    if (glewInit() != GLEW_OK)
    {
        std::cerr << "Failed to initialize GLEW\n";
        glfwTerminate();
        return -1;
    }

    // Ensure we can capture the escape key being pressed below
    glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

    // Set background color
    glClearColor(0.0f, 0.0f, 0.4f, 1.0f);

    // Vertex Array Object
    GLuint VertexArrayID;
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    std::vector<GLfloat> sin_wave_buffer_data;

    for (float x = -20.0f; x <= 20.0f; x++)
    {
        float y;
        if (x == 0)
            y = 1.0f;
        else
            y = sin(x) / x;

        // add to buffer the coordinate (x,y,0)
        sin_wave_buffer_data.push_back(x / 20.0);
        sin_wave_buffer_data.push_back(y / 2.0);
        sin_wave_buffer_data.push_back(0);
    }

    // Sin wave buffer
    GLuint sin_wave_buffer;
    glGenBuffers(1, &sin_wave_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, sin_wave_buffer);
    glBufferData(GL_ARRAY_BUFFER, sin_wave_buffer_data.size() * sizeof(GLfloat), sin_wave_buffer_data.data(), GL_STATIC_DRAW);

    // Load shaders
    GLuint programID = LoadShaders("shaders/2Dflat.vert", "shaders/2Dflat.frag");
    GLuint colorID = glGetUniformLocation(programID, "color_vec");

    do
    {
        // Clear the screen
        glClear(GL_COLOR_BUFFER_BIT);

        // Use shader
        glUseProgram(programID);

        glEnableVertexAttribArray(0);

        glUniform3f(colorID, 1.0f, 0.0f, 0.0f); // red
        glBindBuffer(GL_ARRAY_BUFFER, sin_wave_buffer);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void *)0);
        glLineWidth(1.0f);
        glDrawArrays(GL_LINE_STRIP, 0, sin_wave_buffer_data.size() / 3);

        glDisableVertexAttribArray(0);

        // Swap buffers
        glfwSwapBuffers(window);
        glfwPollEvents();

    } while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
             glfwWindowShouldClose(window) == 0);

    // Cleanup VBO, shader, etc
    glDeleteBuffers(1, &sin_wave_buffer);

    glDeleteVertexArrays(1, &VertexArrayID);
    glDeleteProgram(programID);

    // Close OpenGL window and terminate GLFW
    glfwTerminate();

    return 0;
}
