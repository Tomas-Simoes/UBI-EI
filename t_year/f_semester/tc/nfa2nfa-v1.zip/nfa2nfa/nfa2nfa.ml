open Ppx_yojson_conv_lib.Yojson_conv.Primitives

type estado = int [@@deriving yojson]

type simbolo = char option [@@deriving yojson]

type transicao = (estado * simbolo) * estado [@@deriving yojson]

(* o nosso nfa *)
type nfa =
  estado list * char list * transicao list * estado list * estado list
[@@deriving yojson]

let rec read_multiplelines () =
  try
    let line = read_line () in
    line ^ " " ^ read_multiplelines ()
  with End_of_file -> ""

let nfa_de_string s = s |> Yojson.Safe.from_string |> nfa_of_yojson

let nfa_para_string nfa = yojson_of_nfa nfa |> Yojson.Safe.to_string

let ordenar_nfa nfa =
  let (estados, alfabeto, transicoes, iniciais, finais) = nfa in
  let estados_ordenados = List.sort_uniq compare estados in
  let alfabeto_ordenado = List.sort_uniq compare alfabeto in
  let transicoes_ordenadas = List.sort_uniq compare transicoes in
  let iniciais_ordenados = List.sort_uniq compare iniciais in
  let finais_ordenados = List.sort_uniq compare finais in
  (estados_ordenados, alfabeto_ordenado, transicoes_ordenadas, iniciais_ordenados, finais_ordenados)


let _ =
  let s = read_multiplelines () |> String.trim in

  (* deve editar as chamadas aqui ... *)

  let nfa = s |> nfa_de_string in

  (* deve verificar se s tem epsilon *)
  (*
    if ... then (
      print_endline "EPSILON";
      exit 0
    );
  *)
  

  (* imprimir nfa *)
  print_endline (nfa_para_string (ordenar_nfa nfa))
