:- use_module(library(tty)).
:- use_module(ui).

main :- 
    ui:main_menu.
